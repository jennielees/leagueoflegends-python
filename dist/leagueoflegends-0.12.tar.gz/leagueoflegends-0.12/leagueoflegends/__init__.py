from .leagueoflegends import LeagueOfLegends, RiotError
